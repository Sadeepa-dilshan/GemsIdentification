<!-- resources/views/gems/index.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>Gems List</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <style>
        main {
            margin: 20px;
            margin-top: 2rem !important;
        }
        .action-button {
            margin: 5px;
        }
        .dataTables_wrapper .dataTables_filter {
            float: right;
            text-align: right;
        }
        .dataTables_wrapper .dataTables_length {
            float: left;
        }
        .dataTables_wrapper .dataTables_info {
            float: left;
        }
        .dataTables_wrapper .dataTables_paginate {
            float: right;
        }
        body {
            background-color: #c4996c;;
             /* Add your background image path here */
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
        }
        @media (max-width: 767px) {
            main {
                margin: 10px;
            }
            .dataTables_wrapper .dataTables_filter,
            .dataTables_wrapper .dataTables_length,
            .dataTables_wrapper .dataTables_info,
            .dataTables_wrapper .dataTables_paginate {
                float: none;
                text-align: center;
                margin-bottom: 10px;
            }
            .dataTables_wrapper .dataTables_paginate {
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <main>
        <div class="container mt-5">
            
            <div class="table-responsive">
                <table id="gems-table" class="display table table-striped table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>ID</th>
                            <th>Species</th>
                            <th>Variety</th>
                            <th>Shape & Cutting Style</th>
                            <th>Measurements</th>
                            <th>Carat Weight</th>
                            <th>Color</th>
                            <th>Transparency</th>
                            <th>User Name</th>
                            <th>Mobile</th>
                            <th>Address</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $gems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($gem->id); ?></td>
                            <td><?php echo e($gem->species); ?></td>
                            <td><?php echo e($gem->variety); ?></td>
                            <td><?php echo e($gem->shape_cutting_style); ?></td>
                            <td><?php echo e($gem->measurements); ?></td>
                            <td><?php echo e($gem->carat_weight); ?></td>
                            <td><?php echo e($gem->color); ?></td>
                            <td><?php echo e($gem->transparency); ?></td>
                            <td><?php echo e($gem->userDetail->name); ?></td>
                            <td><?php echo e($gem->userDetail->mobile); ?></td>
                            <td><?php echo e($gem->userDetail->address); ?></td>
                            <td>
                                <a href="<?php echo e(route('gems.downloadReport', $gem->id)); ?>" class="btn btn-primary btn-sm action-button">Download Report</a>
                                <a href="<?php echo e(route('gems.downloadCard', $gem->id)); ?>" class="btn btn-secondary btn-sm action-button">Download Card</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <script>
            $(document).ready(function() {
                $('#gems-table').DataTable({
                    responsive: true,
                    autoWidth: false,
                    language: {
                        search: "Filter records:"
                    },
                    lengthMenu: [
                        [10, 25, 50, -1],
                        [10, 25, 50, "All"]
                    ]
                });
            });
        </script>
    </main>
</body>
</html>
<?php /**PATH C:\laravel\gemIdentification\resources\views/gems/index.blade.php ENDPATH**/ ?>